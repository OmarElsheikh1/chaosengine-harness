package com.saucedemo.tests;

import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import com.shaft.driver.SHAFT;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTests {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    @BeforeClass
    public void loadTestData() {
        testData = new SHAFT.TestData.JSON("saucedemo.json");
    }

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void standardUserCanLogIn() {
        new LoginPage(driver)
                .open()
                .login(testData.get("username"), testData.get("password"))
                .assertLoggedIn(testData.get("inventoryTitle"), testData.get("inventoryPath"));
    }

    @Test
    public void standardUserCanAddItemAndCompleteCheckout() {
        InventoryPage inventory = new LoginPage(driver)
                .open()
                .login(testData.get("username"), testData.get("password"));

        inventory.addBackpackToCart()
                .assertCartCount(testData.get("cartCount"))
                .openCart()
                .assertItemPresent(testData.get("itemName"))
                .startCheckout()
                .enterCustomerInformation(
                        testData.get("firstName"),
                        testData.get("lastName"),
                        testData.get("postalCode"))
                .continueToOverview()
                .assertItemPresent(testData.get("itemName"))
                .finish()
                .assertOrderComplete(testData.get("orderConfirmation"), testData.get("completePath"));
    }
}
