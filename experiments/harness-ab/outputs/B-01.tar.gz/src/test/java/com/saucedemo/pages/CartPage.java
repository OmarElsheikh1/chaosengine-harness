package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CartPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By checkoutButton = By.cssSelector("[data-test='checkout']");

    public CartPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CartPage assertItemPresent(String expectedName) {
        driver.assertThat().element(itemName).text().isEqualTo(expectedName);
        return this;
    }

    public CheckoutPage startCheckout() {
        driver.element().click(checkoutButton);
        return new CheckoutPage(driver);
    }
}
