package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By title = By.cssSelector("[data-test='title']");
    private final By addBackpack = By.cssSelector("[data-test='add-to-cart-sauce-labs-backpack']");
    private final By cartBadge = By.cssSelector("[data-test='shopping-cart-badge']");
    private final By cartLink = By.cssSelector("[data-test='shopping-cart-link']");

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public InventoryPage assertLoggedIn(String expectedTitle, String expectedPath) {
        driver.assertThat().browser().url().contains(expectedPath);
        driver.assertThat().element(title).text().isEqualTo(expectedTitle);
        return this;
    }

    public InventoryPage addBackpackToCart() {
        driver.element().click(addBackpack);
        return this;
    }

    public InventoryPage assertCartCount(String expectedCount) {
        driver.assertThat().element(cartBadge).text().isEqualTo(expectedCount);
        return this;
    }

    public CartPage openCart() {
        driver.element().click(cartLink);
        return new CartPage(driver);
    }
}
