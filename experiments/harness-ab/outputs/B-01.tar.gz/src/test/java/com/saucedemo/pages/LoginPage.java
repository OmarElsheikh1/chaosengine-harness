package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class LoginPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By usernameField = By.cssSelector("[data-test='username']");
    private final By passwordField = By.cssSelector("[data-test='password']");
    private final By loginButton = By.cssSelector("[data-test='login-button']");

    public LoginPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open() {
        driver.browser().navigateToURL(SHAFT.Properties.web.baseURL());
        return this;
    }

    public InventoryPage login(String username, String password) {
        driver.element().type(usernameField, username)
                .and().element().type(passwordField, password)
                .and().element().click(loginButton);
        return new InventoryPage(driver);
    }
}
