package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By firstName = By.cssSelector("[data-test='firstName']");
    private final By lastName = By.cssSelector("[data-test='lastName']");
    private final By postalCode = By.cssSelector("[data-test='postalCode']");
    private final By continueButton = By.cssSelector("[data-test='continue']");
    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By finishButton = By.cssSelector("[data-test='finish']");
    private final By completeHeader = By.cssSelector("[data-test='complete-header']");

    public CheckoutPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutPage enterCustomerInformation(String givenName, String familyName, String zipCode) {
        driver.element().type(firstName, givenName)
                .and().element().type(lastName, familyName)
                .and().element().type(postalCode, zipCode);
        return this;
    }

    public CheckoutPage continueToOverview() {
        driver.element().click(continueButton);
        return this;
    }

    public CheckoutPage assertItemPresent(String expectedName) {
        driver.assertThat().element(itemName).text().isEqualTo(expectedName);
        return this;
    }

    public CheckoutPage finish() {
        driver.element().click(finishButton);
        return this;
    }

    public CheckoutPage assertOrderComplete(String expectedMessage, String expectedPath) {
        driver.assertThat().browser().url().contains(expectedPath);
        driver.assertThat().element(completeHeader).text().isEqualTo(expectedMessage);
        return this;
    }
}
