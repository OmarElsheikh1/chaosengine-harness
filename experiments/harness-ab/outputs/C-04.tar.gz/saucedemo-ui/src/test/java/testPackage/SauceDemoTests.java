package testPackage;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTests {
    private static final String BASE_URL = "https://www.saucedemo.com/";
    private static final String USERNAME = "standard_user";
    private static final String PASSWORD = "secret_sauce";

    private SHAFT.GUI.WebDriver driver;

    private final By usernameField = By.id("user-name");
    private final By passwordField = By.id("password");
    private final By loginButton = By.id("login-button");
    private final By productsTitle = By.cssSelector("[data-test='title']");
    private final By addBackpack = By.id("add-to-cart-sauce-labs-backpack");
    private final By cartLink = By.className("shopping_cart_link");
    private final By cartItemName = By.className("inventory_item_name");
    private final By checkoutButton = By.id("checkout");
    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By postalCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By finishButton = By.id("finish");
    private final By completeHeader = By.cssSelector("[data-test='complete-header']");

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void loginWithStandardUserShowsInventory() {
        login();
        driver.browser().assertThat().url().contains("inventory.html");
        driver.element().assertThat(productsTitle).text().contains("Products");
    }

    @Test
    public void addBackpackToCartAndCompleteCheckout() {
        login();
        driver.element().click(addBackpack);
        driver.element().click(cartLink);
        driver.element().assertThat(cartItemName).text().contains("Sauce Labs Backpack");
        driver.element().click(checkoutButton);
        driver.element().type(firstNameField, "Ada");
        driver.element().type(lastNameField, "Lovelace");
        driver.element().type(postalCodeField, "12345");
        driver.element().click(continueButton);
        driver.element().click(finishButton);
        driver.element().assertThat(completeHeader).text().contains("Thank you for your order!");
    }

    private void login() {
        driver.browser().navigateToURL(BASE_URL);
        driver.element().type(usernameField, USERNAME);
        driver.element().type(passwordField, PASSWORD);
        driver.element().click(loginButton);
    }
}
