package testPackage;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTests {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    private final By usernameField = By.id("user-name");
    private final By passwordField = By.id("password");
    private final By loginButton = By.id("login-button");
    private final By productsTitle = By.cssSelector(".title");
    private final By addBackpack = By.id("add-to-cart-sauce-labs-backpack");
    private final By cartBadge = By.cssSelector(".shopping_cart_badge");
    private final By cartLink = By.cssSelector("a.shopping_cart_link");
    private final By cartItemName = By.cssSelector(".inventory_item_name");
    private final By checkoutButton = By.id("checkout");
    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By postalCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By finishButton = By.id("finish");
    private final By completeHeader = By.cssSelector(".complete-header");

    @BeforeClass
    public void loadTestData() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void standardUserLogsIn() {
        login();
        driver.element().assertThat(productsTitle).text()
                .isEqualTo(testData.get("productsTitle")).perform();
    }

    @Test
    public void standardUserAddsBackpackAndCompletesCheckout() {
        login();
        // Native click reports success on this React button without adding the item.
        driver.element().clickUsingJavascript(addBackpack);
        driver.element().assertThat(cartBadge).text().isEqualTo("1").perform();
        driver.element().click(cartLink);
        driver.element().assertThat(cartItemName).text()
                .isEqualTo(testData.get("itemName")).perform();
        driver.element().click(checkoutButton);
        driver.element().type(firstNameField, testData.get("firstName"));
        driver.element().type(lastNameField, testData.get("lastName"));
        driver.element().type(postalCodeField, testData.get("postalCode"));
        driver.element().click(continueButton);
        driver.element().assertThat(cartItemName).text()
                .isEqualTo(testData.get("itemName")).perform();
        driver.element().click(finishButton);
        driver.element().assertThat(completeHeader).text()
                .isEqualTo(testData.get("completeHeader")).perform();
    }

    private void login() {
        driver.browser().navigateToURL(testData.get("baseUrl"));
        driver.element().type(usernameField, testData.get("username"));
        driver.element().typeSecure(passwordField, testData.get("password"));
        driver.element().click(loginButton);
    }
}
