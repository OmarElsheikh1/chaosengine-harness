package testPackage;

import com.shaft.driver.SHAFT;
import com.shaft.gui.internal.locator.Locator;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTest {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    private final By usernameField = Locator.hasAnyTagName().hasAttribute("data-test", "username").build();
    private final By passwordField = Locator.hasAnyTagName().hasAttribute("data-test", "password").build();
    private final By loginButton = Locator.hasAnyTagName().hasAttribute("data-test", "login-button").build();
    private final By productsTitle = Locator.hasAnyTagName().hasAttribute("data-test", "title").build();
    private final By addBackpackButton = Locator.hasAnyTagName().hasAttribute("data-test", "add-to-cart-sauce-labs-backpack").build();
    private final By cartBadge = Locator.hasAnyTagName().hasAttribute("data-test", "shopping-cart-badge").build();
    private final By cartLink = Locator.hasAnyTagName().hasAttribute("data-test", "shopping-cart-link").build();
    private final By itemName = Locator.hasAnyTagName().hasAttribute("data-test", "inventory-item-name").build();
    private final By checkoutButton = Locator.hasAnyTagName().hasAttribute("data-test", "checkout").build();
    private final By firstNameField = Locator.hasAnyTagName().hasAttribute("data-test", "firstName").build();
    private final By lastNameField = Locator.hasAnyTagName().hasAttribute("data-test", "lastName").build();
    private final By postalCodeField = Locator.hasAnyTagName().hasAttribute("data-test", "postalCode").build();
    private final By continueButton = Locator.hasAnyTagName().hasAttribute("data-test", "continue").build();
    private final By finishButton = Locator.hasAnyTagName().hasAttribute("data-test", "finish").build();
    private final By completeHeader = Locator.hasAnyTagName().hasAttribute("data-test", "complete-header").build();

    @Test
    public void loginWithStandardUserShowsProducts() {
        login();
        driver.element().assertThat(productsTitle).text().contains(testData.get("productsTitle"));
        driver.assertThat().browser().url().contains(testData.get("inventoryPath"));
    }

    @Test
    public void addBackpackToCartAndCompleteCheckout() {
        login();
        driver.element().click(addBackpackButton);
        driver.element().assertThat(cartBadge).text().isEqualTo(testData.get("cartCount"));
        driver.element().click(cartLink);
        driver.element().assertThat(itemName).text().isEqualTo(testData.get("itemName"));
        driver.element().click(checkoutButton);
        driver.element().type(firstNameField, testData.get("firstName"))
                .and().type(lastNameField, testData.get("lastName"))
                .and().type(postalCodeField, testData.get("postalCode"))
                .and().click(continueButton);
        driver.element().assertThat(itemName).text().isEqualTo(testData.get("itemName"));
        driver.element().click(finishButton);
        driver.element().assertThat(completeHeader).text().isEqualTo(testData.get("completeHeader"));
        driver.assertThat().browser().url().contains(testData.get("checkoutCompletePath"));
    }

    private void login() {
        driver.browser().navigateToURL(testData.get("baseUrl"))
                .and().element().type(usernameField, testData.get("username"))
                .and().type(passwordField, testData.get("password"))
                .and().click(loginButton);
    }

    @BeforeClass
    public void beforeClass() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void beforeMethod() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod
    public void afterMethod() {
        driver.quit();
    }
}
