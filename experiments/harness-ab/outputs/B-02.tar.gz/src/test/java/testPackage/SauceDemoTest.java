package testPackage;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTest {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    private final By username = By.cssSelector("[data-test='username']");
    private final By password = By.cssSelector("[data-test='password']");
    private final By loginButton = By.cssSelector("[data-test='login-button']");
    private final By pageTitle = By.cssSelector("[data-test='title']");
    private final By addBackpack = By.cssSelector("[data-test='add-to-cart-sauce-labs-backpack']");
    private final By cartBadge = By.cssSelector("[data-test='shopping-cart-badge']");
    private final By cartLink = By.cssSelector("[data-test='shopping-cart-link']");
    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By checkoutButton = By.cssSelector("[data-test='checkout']");
    private final By firstName = By.cssSelector("[data-test='firstName']");
    private final By lastName = By.cssSelector("[data-test='lastName']");
    private final By postalCode = By.cssSelector("[data-test='postalCode']");
    private final By continueButton = By.cssSelector("[data-test='continue']");
    private final By finishButton = By.cssSelector("[data-test='finish']");
    private final By completeHeader = By.cssSelector("[data-test='complete-header']");

    @Test
    public void standardUserLogsInAndSeesProducts() {
        login();
        driver.assertThat().browser().url().contains(testData.get("inventoryPath"));
        driver.element().assertThat(pageTitle).text().isEqualTo(testData.get("productsTitle"));
    }

    @Test
    public void addBackpackToCartAndCompleteCheckout() {
        login();
        // Inventory actions are React handlers. A native WebDriver click reports success
        // without firing them in this Chrome, so the click has to go through JavaScript.
        driver.element().clickUsingJavascript(addBackpack);
        driver.element().assertThat(cartBadge).text().isEqualTo(testData.get("cartBadge"));

        driver.element().clickUsingJavascript(cartLink);
        driver.element().assertThat(itemName).text().isEqualTo(testData.get("productName"));

        driver.element().clickUsingJavascript(checkoutButton);
        driver.element().type(firstName, testData.get("firstName"))
                .and().element().type(lastName, testData.get("lastName"))
                .and().element().type(postalCode, testData.get("postalCode"))
                .and().element().clickUsingJavascript(continueButton);

        driver.element().assertThat(pageTitle).text().isEqualTo(testData.get("overviewTitle"));
        driver.element().assertThat(itemName).text().isEqualTo(testData.get("productName"));

        driver.element().clickUsingJavascript(finishButton);
        driver.element().assertThat(completeHeader).text().isEqualTo(testData.get("completeHeader"));
    }

    private void login() {
        driver.browser().navigateToURL(testData.get("baseUrl"));
        driver.element().type(username, testData.get("username"))
                .and().element().type(password, testData.get("password"))
                .and().element().click(loginButton);
    }

    @BeforeClass
    public void beforeClass() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void beforeMethod() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        if (driver != null) {
            driver.quit();
        }
    }
}
