package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CartPage extends Page {
    private final By itemName = byTestId("inventory-item-name");
    private final By checkoutButton = byId("checkout");

    public CartPage(SHAFT.GUI.WebDriver driver) {
        super(driver);
    }

    public CartPage assertItemIsListed(String expectedName) {
        driver.assertThat().browser().url().contains("cart.html");
        driver.element().assertThat(itemName).text().isEqualTo(expectedName);
        return this;
    }

    public CheckoutInformationPage checkout() {
        click(checkoutButton);
        return new CheckoutInformationPage(driver);
    }
}
