package com.saucedemo.tests;

import com.saucedemo.pages.LoginPage;
import org.testng.annotations.Test;

public class CheckoutTest extends TestBase {

    @Test
    public void userAddsBackpackToCartAndCompletesCheckout() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"))
                .addBackpackToCart()
                .assertCartBadge(testData.get("cartBadge"))
                .openCart()
                .assertItemIsListed(testData.get("itemName"))
                .checkout()
                .continueWith(testData.get("firstName"), testData.get("lastName"), testData.get("postalCode"))
                .assertItemIsListed(testData.get("itemName"))
                .finish()
                .assertOrderIsComplete(testData.get("completeHeader"));
    }
}
