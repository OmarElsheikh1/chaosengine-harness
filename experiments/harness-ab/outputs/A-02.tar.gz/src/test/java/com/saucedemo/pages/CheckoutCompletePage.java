package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutCompletePage extends Page {
    private final By completeHeader = byTestId("complete-header");

    public CheckoutCompletePage(SHAFT.GUI.WebDriver driver) {
        super(driver);
    }

    public CheckoutCompletePage assertOrderIsComplete(String expectedHeader) {
        driver.assertThat().browser().url().contains("checkout-complete.html");
        driver.element().assertThat(completeHeader).text().isEqualTo(expectedHeader);
        return this;
    }
}
