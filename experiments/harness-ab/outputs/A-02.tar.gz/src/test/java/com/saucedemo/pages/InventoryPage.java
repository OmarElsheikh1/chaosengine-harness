package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage extends Page {
    private final By productsTitle = byTestId("title");
    private final By addBackpackButton = byId("add-to-cart-sauce-labs-backpack");
    private final By removeBackpackButton = byId("remove-sauce-labs-backpack");
    private final By cartBadge = byTestId("shopping-cart-badge");
    private final By cartLink = byTestId("shopping-cart-link");

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        super(driver);
    }

    public InventoryPage assertLoaded(String expectedTitle) {
        driver.assertThat().browser().url().contains("inventory.html");
        driver.element().assertThat(productsTitle).text().isEqualTo(expectedTitle);
        return this;
    }

    public InventoryPage addBackpackToCart() {
        click(addBackpackButton);
        driver.element().assertThat(removeBackpackButton).isVisible();
        return this;
    }

    public InventoryPage assertCartBadge(String expectedCount) {
        driver.element().assertThat(cartBadge).text().isEqualTo(expectedCount);
        return this;
    }

    public CartPage openCart() {
        click(cartLink);
        return new CartPage(driver);
    }
}
