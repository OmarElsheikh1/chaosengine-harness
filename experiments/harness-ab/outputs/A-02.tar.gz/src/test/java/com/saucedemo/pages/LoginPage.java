package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class LoginPage extends Page {
    private final By usernameField = byId("user-name");
    private final By passwordField = byId("password");
    private final By loginButton = byId("login-button");

    public LoginPage(SHAFT.GUI.WebDriver driver) {
        super(driver);
    }

    public LoginPage open(String baseUrl) {
        driver.browser().navigateToURL(baseUrl);
        driver.element().assertThat(loginButton).isVisible();
        return this;
    }

    public InventoryPage login(String username, String password) {
        driver.element().type(usernameField, username)
                .and().element().type(passwordField, password);
        click(loginButton);
        return new InventoryPage(driver);
    }
}
