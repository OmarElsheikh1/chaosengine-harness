package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutInformationPage extends Page {
    private final By firstNameField = byId("first-name");
    private final By lastNameField = byId("last-name");
    private final By postalCodeField = byId("postal-code");
    private final By continueButton = byId("continue");

    public CheckoutInformationPage(SHAFT.GUI.WebDriver driver) {
        super(driver);
    }

    public CheckoutOverviewPage continueWith(String firstName, String lastName, String postalCode) {
        driver.assertThat().browser().url().contains("checkout-step-one.html");
        typeControlledInput(firstNameField, "first-name", firstName);
        typeControlledInput(lastNameField, "last-name", lastName);
        typeControlledInput(postalCodeField, "postal-code", postalCode);
        click(continueButton);
        return new CheckoutOverviewPage(driver);
    }
}
