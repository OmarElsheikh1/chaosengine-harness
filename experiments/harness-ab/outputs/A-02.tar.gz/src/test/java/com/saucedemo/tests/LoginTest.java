package com.saucedemo.tests;

import com.saucedemo.pages.LoginPage;
import org.testng.annotations.Test;

public class LoginTest extends TestBase {

    @Test
    public void userLogsInWithValidCredentials() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"))
                .assertLoaded(testData.get("productsTitle"));
    }
}
