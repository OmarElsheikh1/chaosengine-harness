package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutOverviewPage extends Page {
    private final By itemName = byTestId("inventory-item-name");
    private final By finishButton = byId("finish");

    public CheckoutOverviewPage(SHAFT.GUI.WebDriver driver) {
        super(driver);
    }

    public CheckoutOverviewPage assertItemIsListed(String expectedName) {
        driver.assertThat().browser().url().contains("checkout-step-two.html");
        driver.element().assertThat(itemName).text().isEqualTo(expectedName);
        return this;
    }

    public CheckoutCompletePage finish() {
        click(finishButton);
        return new CheckoutCompletePage(driver);
    }
}
