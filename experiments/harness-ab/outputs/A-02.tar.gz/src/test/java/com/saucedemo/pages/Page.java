package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

import java.util.Map;

abstract class Page {
    protected final SHAFT.GUI.WebDriver driver;

    protected Page(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    protected static By byId(String id) {
        return SHAFT.GUI.Locator.hasAnyTagName().hasId(id).build();
    }

    protected static By byTestId(String testId) {
        return SHAFT.GUI.Locator.hasAnyTagName().hasAttribute("data-test", testId).build();
    }

    /**
     * SauceDemo handles these controls with React click listeners. In headless Chrome 157,
     * SHAFT's native WebDriver click reports success without dispatching that listener.
     */
    protected void click(By locator) {
        driver.element().clickUsingJavascript(locator);
    }

    /**
     * SauceDemo checkout fields are controlled React inputs. SHAFT {@code type()} reports
     * success on them in headless Chrome 157 without changing the DOM value, so the form
     * submits empty. The HTMLInputElement value setter plus an input event updates React state.
     */
    protected void typeControlledInput(By locator, String id, String value) {
        driver.browser().script().evaluate(
                """
                const field = document.getElementById(arguments[0].id);
                const setter = Object.getOwnPropertyDescriptor(
                        window.HTMLInputElement.prototype, 'value').set;
                const previous = field.value;
                setter.call(field, arguments[0].value);
                const tracker = field._valueTracker;
                if (tracker) {
                    tracker.setValue(previous);
                }
                field.dispatchEvent(new Event('input', { bubbles: true }));
                field.dispatchEvent(new Event('change', { bubbles: true }));
                """,
                Map.of("id", id, "value", value));
        driver.element().assertThat(locator).domProperty("value").isEqualTo(value);
    }
}
