package saucedemo;

import org.testng.annotations.Test;

public class LoginTest extends SauceDemoTest {

    @Test
    public void userLogsInWithStandardCredentials() {
        loginAsStandardUser();
        driver.element().assertThat(pageTitle).text().contains(testData.get("inventoryTitle"));
    }
}
