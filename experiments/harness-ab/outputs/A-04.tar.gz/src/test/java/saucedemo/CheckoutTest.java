package saucedemo;

import org.testng.annotations.Test;

public class CheckoutTest extends SauceDemoTest {

    @Test
    public void userAddsBackpackToCartAndCompletesCheckout() {
        loginAsStandardUser();
        driver.element().click(addBackpackButton);
        driver.element().assertThat(cartBadge).text().contains("1");
        driver.element().click(cartLink);
        driver.element().assertThat(itemName).text().contains(testData.get("itemName"));
        driver.element().click(checkoutButton)
                .and().element().type(firstNameField, testData.get("firstName"))
                .and().element().type(lastNameField, testData.get("lastName"))
                .and().element().type(postalCodeField, testData.get("postalCode"))
                .and().element().click(continueButton);
        driver.element().assertThat(itemName).text().contains(testData.get("itemName"));
        driver.element().click(finishButton);
        driver.element().assertThat(completeHeader).text().contains(testData.get("completeHeader"));
    }
}
