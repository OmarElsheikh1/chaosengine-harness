package saucedemo;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public abstract class SauceDemoTest {
    protected SHAFT.GUI.WebDriver driver;
    protected static SHAFT.TestData.JSON testData;

    protected static final By usernameField = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "username").build();
    protected static final By passwordField = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "password").build();
    protected static final By loginButton = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "login-button").build();
    protected static final By pageTitle = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "title").build();
    protected static final By addBackpackButton = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "add-to-cart-sauce-labs-backpack").build();
    protected static final By cartBadge = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "shopping-cart-badge").build();
    protected static final By cartLink = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "shopping-cart-link").build();
    protected static final By itemName = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "inventory-item-name").build();
    protected static final By checkoutButton = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "checkout").build();
    protected static final By firstNameField = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "firstName").build();
    protected static final By lastNameField = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "lastName").build();
    protected static final By postalCodeField = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "postalCode").build();
    protected static final By continueButton = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "continue").build();
    protected static final By finishButton = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "finish").build();
    protected static final By completeHeader = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "complete-header").build();

    @BeforeClass
    public void loadTestData() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    protected void loginAsStandardUser() {
        driver.browser().navigateToURL(testData.get("baseUrl"))
                .and().element().type(usernameField, testData.get("username"))
                .and().element().type(passwordField, testData.get("password"))
                .and().element().click(loginButton);
    }
}
