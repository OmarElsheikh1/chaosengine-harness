package testPackage.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class LoginPage {
    public static final By USERNAME = By.id("user-name");
    public static final By PASSWORD = By.id("password");
    public static final By LOGIN_BUTTON = By.id("login-button");

    private final SHAFT.GUI.WebDriver driver;

    public LoginPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open(String url) {
        driver.browser().navigateToURL(url);
        return this;
    }

    public void login(String username, String password) {
        driver.element()
                .type(USERNAME, username)
                .typeSecure(PASSWORD, password)
                .click(LOGIN_BUTTON);
    }
}
