package testPackage.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutPage {
    public static final By PAGE_HEADING = By.className("title");
    public static final By ITEM_NAME = By.className("inventory_item_name");
    public static final By FIRST_NAME = By.id("first-name");
    public static final By LAST_NAME = By.id("last-name");
    public static final By POSTAL_CODE = By.id("postal-code");
    public static final By CONTINUE_BUTTON = By.id("continue");
    public static final By FINISH_BUTTON = By.id("finish");
    public static final By COMPLETE_HEADER = By.className("complete-header");

    private final SHAFT.GUI.WebDriver driver;

    public CheckoutPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public void fillInformation(String firstName, String lastName, String postalCode) {
        driver.element()
                .type(FIRST_NAME, firstName)
                .type(LAST_NAME, lastName)
                .type(POSTAL_CODE, postalCode)
                .click(CONTINUE_BUTTON);
    }

    public void finish() {
        driver.element().click(FINISH_BUTTON);
    }
}
