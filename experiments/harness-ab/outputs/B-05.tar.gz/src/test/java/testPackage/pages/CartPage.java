package testPackage.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CartPage {
    public static final By PAGE_HEADING = By.className("title");
    public static final By ITEM_NAME = By.className("inventory_item_name");
    public static final By CHECKOUT_BUTTON = By.id("checkout");

    private final SHAFT.GUI.WebDriver driver;

    public CartPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public void startCheckout() {
        driver.element().click(CHECKOUT_BUTTON);
    }
}
