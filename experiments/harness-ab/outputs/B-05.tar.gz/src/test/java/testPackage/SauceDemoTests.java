package testPackage;

import com.shaft.driver.SHAFT;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testPackage.pages.CartPage;
import testPackage.pages.CheckoutPage;
import testPackage.pages.InventoryPage;
import testPackage.pages.LoginPage;

public class SauceDemoTests {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    @BeforeClass
    public void loadTestData() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test(description = "A standard user can log in and reach the product inventory.")
    public void standardUserCanLogIn() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"));

        driver.browser().assertThat().url().contains(testData.get("inventoryUrlFragment"));
        driver.browser().assertThat().title().isEqualTo(testData.get("browserTitle"));
        driver.element().assertThat(InventoryPage.PAGE_HEADING).text().isEqualTo(testData.get("productsHeading"));
        driver.element().assertThat(InventoryPage.INVENTORY_LIST).exists();
    }

    @Test(description = "A standard user can add a backpack to the cart and complete checkout.")
    public void standardUserCanAddItemAndCompleteCheckout() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"));

        InventoryPage inventory = new InventoryPage(driver);
        inventory.addBackpackToCart();
        driver.element().assertThat(InventoryPage.CART_BADGE).text().isEqualTo(testData.get("cartBadgeCount"));

        inventory.openCart();
        driver.browser().assertThat().url().contains(testData.get("cartUrlFragment"));
        driver.element().assertThat(CartPage.PAGE_HEADING).text().isEqualTo(testData.get("cartHeading"));
        driver.element().assertThat(CartPage.ITEM_NAME).text().isEqualTo(testData.get("itemName"));

        new CartPage(driver).startCheckout();
        CheckoutPage checkout = new CheckoutPage(driver);
        checkout.fillInformation(
                testData.get("firstName"),
                testData.get("lastName"),
                testData.get("postalCode"));
        driver.element().assertThat(CheckoutPage.PAGE_HEADING).text().isEqualTo(testData.get("overviewHeading"));
        driver.element().assertThat(CheckoutPage.ITEM_NAME).text().isEqualTo(testData.get("itemName"));

        checkout.finish();
        driver.browser().assertThat().url().contains(testData.get("checkoutCompleteUrlFragment"));
        driver.element().assertThat(CheckoutPage.COMPLETE_HEADER).text().isEqualTo(testData.get("orderCompleteMessage"));
    }
}
