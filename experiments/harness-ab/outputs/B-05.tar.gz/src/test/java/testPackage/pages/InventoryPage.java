package testPackage.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage {
    public static final By PAGE_HEADING = By.className("title");
    public static final By INVENTORY_LIST = By.className("inventory_list");
    public static final By CART_BADGE = By.className("shopping_cart_badge");
    public static final By CART_LINK = By.className("shopping_cart_link");
    public static final By BACKPACK_ADD_BUTTON = By.id("add-to-cart-sauce-labs-backpack");

    private final SHAFT.GUI.WebDriver driver;

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public void addBackpackToCart() {
        driver.element().click(BACKPACK_ADD_BUTTON);
    }

    public void openCart() {
        driver.element().click(CART_LINK);
    }
}
