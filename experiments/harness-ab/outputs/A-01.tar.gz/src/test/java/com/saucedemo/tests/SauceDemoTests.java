package com.saucedemo.tests;

import com.saucedemo.pages.LoginPage;
import com.shaft.driver.SHAFT;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTests {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    @BeforeClass
    public void loadTestData() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void startBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void stopBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void loginWithStandardUser() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"))
                .assertLoaded(testData.get("inventoryTitle"));
    }

    @Test
    public void addItemToCartAndCompleteCheckout() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"))
                .addProduct(testData.get("productName"))
                .assertCartCount("1")
                .openCart()
                .assertContains(testData.get("productName"))
                .checkout()
                .fillInformation(
                        testData.get("firstName"),
                        testData.get("lastName"),
                        testData.get("postalCode"))
                .finish()
                .assertOrderComplete(testData.get("completeHeader"));
    }
}
