package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By pageTitle = By.cssSelector("[data-test='title']");
    private final By cartLink = By.cssSelector("[data-test='shopping-cart-link']");
    private final By cartBadge = By.cssSelector("[data-test='shopping-cart-badge']");

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public InventoryPage assertLoaded(String expectedTitle) {
        driver.assertThat().browser().url().contains("inventory.html");
        driver.assertThat().element(pageTitle).text().contains(expectedTitle);
        return this;
    }

    public InventoryPage addProduct(String productName) {
        driver.element().click(addToCartButton(productName));
        return this;
    }

    public InventoryPage assertCartCount(String expectedCount) {
        driver.assertThat().element(cartBadge).text().contains(expectedCount);
        return this;
    }

    public CartPage openCart() {
        driver.element().click(cartLink);
        return new CartPage(driver);
    }

    private static By addToCartButton(String productName) {
        String slug = productName.toLowerCase().replace(' ', '-');
        return By.id("add-to-cart-" + slug);
    }
}
