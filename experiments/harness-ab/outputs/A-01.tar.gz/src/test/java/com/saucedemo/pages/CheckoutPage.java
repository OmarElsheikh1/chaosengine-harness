package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By postalCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By finishButton = By.id("finish");
    private final By completeHeader = By.cssSelector("[data-test='complete-header']");

    public CheckoutPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutPage fillInformation(String firstName, String lastName, String postalCode) {
        driver.element().type(firstNameField, firstName)
                .and().element().type(lastNameField, lastName)
                .and().element().type(postalCodeField, postalCode)
                .and().element().click(continueButton);
        return this;
    }

    public CheckoutPage finish() {
        driver.assertThat().browser().url().contains("checkout-step-two.html");
        driver.element().click(finishButton);
        return this;
    }

    public CheckoutPage assertOrderComplete(String expectedHeader) {
        driver.assertThat().browser().url().contains("checkout-complete.html");
        driver.assertThat().element(completeHeader).text().contains(expectedHeader);
        return this;
    }
}
