package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class LoginPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By usernameField = By.id("user-name");
    private final By passwordField = By.id("password");
    private final By loginButton = By.id("login-button");

    public LoginPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open(String baseUrl) {
        driver.browser().navigateToURL(baseUrl);
        driver.element().assertThat(loginButton).isVisible();
        return this;
    }

    public InventoryPage login(String username, String password) {
        driver.element().type(usernameField, username)
                .and().element().type(passwordField, password)
                .and().element().click(loginButton);
        return new InventoryPage(driver);
    }
}
