package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CartPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By checkoutButton = By.id("checkout");

    public CartPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CartPage assertContains(String productName) {
        driver.assertThat().browser().url().contains("cart.html");
        driver.assertThat().element(itemName).text().contains(productName);
        return this;
    }

    public CheckoutPage checkout() {
        driver.element().click(checkoutButton);
        return new CheckoutPage(driver);
    }
}
