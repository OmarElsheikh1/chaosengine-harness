package saucedemo;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTest {
    private static final String BASE_URL = "https://www.saucedemo.com/";
    private static final String USERNAME = "standard_user";
    private static final String PASSWORD = "secret_sauce";

    private static final By USERNAME_FIELD = By.id("user-name");
    private static final By PASSWORD_FIELD = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By INVENTORY_TITLE = By.className("title");
    private static final By ADD_BACKPACK = By.id("add-to-cart-sauce-labs-backpack");
    private static final By CART_LINK = By.className("shopping_cart_link");
    private static final By CART_ITEM_NAME = By.className("inventory_item_name");
    private static final By CHECKOUT_BUTTON = By.id("checkout");
    private static final By FIRST_NAME = By.id("first-name");
    private static final By LAST_NAME = By.id("last-name");
    private static final By POSTAL_CODE = By.id("postal-code");
    private static final By CONTINUE_BUTTON = By.id("continue");
    private static final By FINISH_BUTTON = By.id("finish");
    private static final By COMPLETE_HEADER = By.className("complete-header");

    private SHAFT.GUI.WebDriver driver;

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void standardUserCanLogIn() {
        login();
        driver.browser().assertThat().url().contains("inventory.html").perform();
        driver.element().assertThat(INVENTORY_TITLE).text().isEqualTo("Products").perform();
    }

    @Test
    public void standardUserCanAddAnItemAndCompleteCheckout() {
        login();
        driver.element().click(ADD_BACKPACK);
        driver.element().click(CART_LINK);
        driver.element().assertThat(CART_ITEM_NAME).text().isEqualTo("Sauce Labs Backpack").perform();
        driver.element().click(CHECKOUT_BUTTON);
        driver.element().type(FIRST_NAME, "Test");
        driver.element().type(LAST_NAME, "User");
        driver.element().type(POSTAL_CODE, "12345");
        driver.element().click(CONTINUE_BUTTON);
        driver.element().click(FINISH_BUTTON);
        driver.element().assertThat(COMPLETE_HEADER).text().isEqualTo("Thank you for your order!").perform();
    }

    private void login() {
        driver.browser().navigateToURL(BASE_URL);
        driver.element().type(USERNAME_FIELD, USERNAME);
        driver.element().type(PASSWORD_FIELD, PASSWORD);
        driver.element().click(LOGIN_BUTTON);
    }
}
