# Caveman provenance

Bundled from `JuliusBrussee/caveman` under the MIT license.

- Upstream commit: `1e91f1306d602d4ca23618701b1185575ae1869b`
- Skill version: `0.1.0`
- Install is project-local. Companion hooks do not deny tools or hold completion.
