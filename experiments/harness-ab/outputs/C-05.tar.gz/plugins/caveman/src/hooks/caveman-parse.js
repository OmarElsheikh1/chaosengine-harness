#!/usr/bin/env node
// caveman — shared mode-change parser (#602)
//
// Single source of truth for interpreting a user prompt as a caveman mode
// change. Extracted from caveman-mode-tracker.js so the Claude Code hook and
// the opencode plugin can't drift out of sync with each other. The tracker's
// regexes are the reference behavior — every pattern below is copied from it
// verbatim; don't tighten or loosen a match here without a matching change
// (and test) on the tracker side.
//
// parseModeChange(prompt, { getDefaultMode, skipNaturalLanguage, expandedTpl, unwrapQuotes })
//   → { action: 'set', mode }  — caller should activate `mode`
//   → { action: 'clear' }      — caller should deactivate (delete the flag)
//   → { action: 'status' }     — report the current mode without changing state
//   → null                     — prompt does not change state
//
// Options:
//   getDefaultMode      — required; () => resolved default mode string.
//                          Injected rather than required directly so the
//                          caller controls resolution (cwd, env, etc.).
//   skipNaturalLanguage — when true, skip deactivation/activation/brevity
//                          phrase matching entirely. Set this for prompt text
//                          that isn't the user's own words (e.g. a foreign
//                          slash-command envelope's <command-args>), so
//                          another command's arguments can't misfire our
//                          triggers.
//   expandedTpl         — when true, also recognize opencode's expanded
//                          command-template bodies (a typed "/ultracave"
//                          gets replaced by the command file's prose before
//                          this parser ever sees it). Claude Code prompts
//                          never take this shape, so Claude Code callers
//                          should leave this off.
//   unwrapQuotes        — when true, strip a single layer of matching quote
//                          characters wrapping the whole prompt (opencode's
//                          non-interactive `run` path delivers messages this
//                          way).

// Sibling require that tolerates the opencode install layout, where this
// file is copied next to a renamed `caveman-config.cjs` (the plugin dir is
// "type": "module", so a bare `.js` sibling would load as ESM). A plain
// `require('./caveman-config')` only auto-resolves the `.js` extension, so
// try that first (dev tree, standalone hook install) and fall back to the
// explicit `.cjs` name.
let cavemanConfig;
try {
  cavemanConfig = require('./caveman-config');
} catch (e) {
  cavemanConfig = require('./caveman-config.cjs');
}
const { VALID_MODES } = cavemanConfig;
// Maps the legacy level names (`/caveman ultra`, `/caveman wenyan-lite`, ...)
// onto the three skills. The stand-in covers a config module from before the
// three-skill model (#848 plugin-cache drift): current ids only.
const canonicalMode = cavemanConfig.canonicalMode
  || ((m) => (VALID_MODES.includes(m) ? m : null));

// Each prose mode has its own command, bare or plugin-namespaced.
const MODE_COMMANDS = {
  '/ultracave': 'ultracave', '/caveman:ultracave': 'ultracave',
  '/megacave': 'megacave', '/caveman:megacave': 'megacave',
};

// Modes handled by their own slash commands (/caveman-commit, etc.) — not
// selectable via /caveman <arg>.
const INDEPENDENT_MODES = new Set(['commit', 'review', 'compress']);

// Natural-language triggers run over the whole prompt, so any pasted text that
// merely QUOTES them fired them — a bug report quoting the /caveman-help card's
// own line ("Say \"stop caveman\" or \"normal mode\".") switched caveman off
// mid-task (#838). #537's envelope unwrap closed the slash-command path; this
// is the prose path, which needs no envelope.
//
// Blank quoted spans before matching. A prompt-length cap looked like the fix
// and is worse on both sides: it still fires on any short quoted line, and it
// silently breaks the compound instructions people actually type ("turn off
// caveman and write the release notes for ..."). That failure is the dangerous
// direction — a false activation is a nuisance, but a deactivation that is
// dropped in silence leaves the user unable to escape the mode with no
// feedback explaining why.
//
// Only " and ` count as delimiters. Apostrophes are far too common in ordinary
// English ("don't stop caveman, it's useful") and pairing on them would blank
// the command itself.
const QUOTED_SPAN_REGEX = /(["`])(?:(?!\1).)*\1/g;

// A mode argument with punctuation glued to it ("/caveman ultra; still too
// verbose") matched no mode, left the mode untouched, and said nothing. Only
// parts[1] is ever read, so extra WORDS after the mode were already harmless;
// it is the trailing character that broke it. Modes are [a-z-] only, so
// stripping every trailing character outside that class is safe.
// Trailing punctuation only. A leading quote or bracket is stripped too so
// `/caveman "ultra"` resolves — asymmetric handling would leave a second,
// equally silent failure right next to the one being fixed.
// The span between an activation verb and "caveman" used to be any 40
// characters (`[^.]{0,40}`), which made ordinary prose an activation command:
// "i want to start building a caveman-themed game" is `want` … `caveman` with
// nothing but prose in between (#187). Real activation phrases only ever put
// determiners and particles in that gap ("turn on THE caveman mode", "switch
// TO caveman"), so the gap is a whitelist now rather than a length budget.
//
// "a"/"an" are deliberately absent. No genuine activation phrase needs one,
// and admitting them is exactly what makes "start a caveman fire" read as a
// command — the question guard catches that phrasing only while it happens to
// be spelled as a question.
const ACTIVATION_VERBS = '(?:activate|enable|start|turn on|use|switch to|want|give me)';
const ACTIVATION_GAP = '(?:\\s+(?:the|to|into|on|in|please|now|it|me|my|this|that|mode))*';
const ACTIVATION_VERB_PHRASE = new RegExp(
  '\\b' + ACTIVATION_VERBS + '\\b' + ACTIVATION_GAP + '\\s+caveman\\b'
);
// "talk like caveman" / "talk like a caveman" — same tightening, but this one
// keeps the article: it is the idiomatic form of the phrase.
const ACTIVATION_TALK_LIKE = /\btalk\s+like\s+(?:a\s+|an\s+|the\s+)?caveman\b/;

// A negated activation is not an activation ("don't activate caveman"). This
// guard is deliberately ASYMMETRIC — the deactivation side keeps firing on
// "don't stop caveman", per the committed behavior in #838: a dropped
// deactivation is silent and leaves the user unable to escape the mode, while
// a spurious one costs a single "/caveman" to undo.
const NEGATOR = /\b(?:don['’]?t|do not|doesn['’]?t|does not|won['’]?t|will not|never|no need to|rather not)\b/;

// The negator does not reliably sit next to the verb it negates. In "don't
// want you to use caveman" it attaches to `want`, while the trigger that
// actually matches is the `use` inside the complement clause — so a fixed
// "negator, then up to N words, then the verb" window misses it, and widening
// that window far enough to catch it starts swallowing unrelated text.
//
// Scope the guard to the CLAUSE instead: a trigger is negated when a negator
// appears between the last clause boundary and the trigger itself. That is
// what keeps a later independent command alive — in "don't use vim, activate
// caveman" the comma ends the negated clause, so the activation still stands.
// Dashes and colons separate clauses the same way a comma does ("never mind
// the linter — turn on caveman"), so they end a negated clause too.
const CLAUSE_BOUNDARY = /[.;!?,:—–]|\s-+\s|\bbut\b|\bthen\b/g;

function negatedBefore(text, index) {
  CLAUSE_BOUNDARY.lastIndex = 0;
  let clauseStart = 0;
  let m;
  while ((m = CLAUSE_BOUNDARY.exec(text)) !== null) {
    if (m.index >= index) break;
    clauseStart = m.index + m[0].length;
  }
  return NEGATOR.test(text.slice(clauseStart, index));
}

// Every phrasing that means "switch caveman on". Kept as one list so the
// negation check applies uniformly — a guard on only the verb form would let
// "don't put caveman mode on" through.
const BREVITY_TRIGGER = /\b(less tokens|fewer tokens|be brief|be terse|shorter answers)\b(?!\s+(in|for|on|about|when|during|with)\b)/;
const ACTIVATION_TRIGGERS = [
  ACTIVATION_VERB_PHRASE,
  ACTIVATION_TALK_LIKE,
  /\bcaveman\s+mode\s+(on|please|now)\b/,
  /^caveman(\s+mode)?\s*[.!]*$/,
  BREVITY_TRIGGER,
].map(re => new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g'));

// True when any trigger matches outside a negated clause. Every match is
// examined, not just the first: the first may be negated while a later,
// independent one is not.
function wantsActivation(text) {
  for (const re of ACTIVATION_TRIGGERS) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(text)) !== null) {
      if (!negatedBefore(text, m.index)) return true;
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  }
  return false;
}

function normalizeModeArg(arg) {
  return (arg || '').replace(/^[^a-z0-9]+/, '').replace(/[^a-z0-9-]+$/, '');
}

// Resolve a /caveman argument to a verdict. An argument that resolves to
// nothing returns 'unresolved' rather than null, so the caller can say so
// instead of failing silently. 'unresolved' is additive: applyModeChange in the
// opencode plugin acts only on 'set'/'clear' and ignores anything else.
function resolveModeArg(rawArg, getDefaultMode) {
  const arg = normalizeModeArg(rawArg);
  if (!arg) {
    // Only a genuinely ABSENT argument means "bare /caveman → activate at the
    // default". An argument that was present but normalized away is punctuation
    // like `/caveman ?` — plausibly someone asking for help, who should not be
    // switched into the mode by it.
    if (rawArg) return { action: 'unresolved' };
    const configured = getDefaultMode();
    const mode = configured === 'manual' ? 'caveman' : configured;
    return mode === 'off' ? { action: 'clear' } : { action: 'set', mode };
  }
  if (arg === 'off' || arg === 'stop' || arg === 'disable') return { action: 'clear' };
  if (arg === 'status') return { action: 'status' };
  // An independent mode IS a real mode, just not reachable this way. Saying
  // "not recognized" would deny a mode the user can see in the docs; name its
  // own command instead. Echoing `arg` here is safe precisely because it
  // matched this fixed whitelist — it is no longer free-form user text.
  if (INDEPENDENT_MODES.has(arg)) return { action: 'unresolved', independentMode: arg };
  // caveman/ultracave/megacave, or a legacy level name mapped onto one.
  const mode = canonicalMode(arg);
  if (mode && mode !== 'off') return { action: 'set', mode };
  // Bogus argument: never silently overwrite with the default (#602). The
  // rejected string is untrusted input and is deliberately NOT echoed back —
  // it would land in model context.
  return { action: 'unresolved' };
}

function parseModeChange(promptRaw, options) {
  options = options || {};
  const getDefaultMode = options.getDefaultMode || cavemanConfig.getDefaultMode;

  let prompt = (promptRaw || '').trim();
  if (options.unwrapQuotes) {
    const wrapped = /^(["'`])([\s\S]*)\1$/.exec(prompt);
    if (wrapped) prompt = wrapped[2].trim();
  }
  // Capture the first line before whitespace collapse. The expandedTpl
  // templates (opencode's commands/caveman.md etc.) put $ARGUMENTS at the end
  // of the first line, followed by a blank line and then fixed boilerplate
  // ("If no argument given, use caveman. If \"off\", deactivate."). Collapsing
  // all whitespace to single spaces (below) merges an EMPTY argument directly
  // into that boilerplate, so a bare `/caveman` with no argument looked like
  // the argument was the word "if" and got rejected as bogus. Extract the
  // template argument from this uncollapsed first line instead.
  const firstLine = prompt.toLowerCase().split(/\r?\n/, 1)[0];
  // Collapse whitespace so phrase triggers still match multiline prompts —
  // every regex below expects a single-line prompt (#598).
  prompt = prompt.toLowerCase().replace(/\s+/g, ' ');
  if (!prompt) return null;

  // Deactivation intent — computed FIRST so "turn caveman mode off" never
  // falls through to the activation patterns (#598), and applied with the
  // highest priority: it's what the tracker's original unconditional
  // end-of-function deactivation check amounted to.
  // Matched against nlPrompt (quoted spans blanked, see QUOTED_SPAN_REGEX) so a
  // prompt that CITES a trigger does not fire it. A prompt that starts with a
  // slash is a command invocation: its own text must not toggle our mode,
  // symmetric with the skipNaturalLanguage a foreign command envelope sets.
  // opencode's expanded /caveman-help card lists the commands and quotes the
  // triggers; its prose ("Activate caveman" once the backtick span is blanked)
  // must not switch the mode. Checked before every trigger, deactivation too.
  if (options.expandedTpl && /^show the caveman quick-reference card\b/.test(prompt)) return null;

  const naturalLanguage = !options.skipNaturalLanguage && !prompt.startsWith('/');
  const nlPrompt = naturalLanguage ? prompt.replace(QUOTED_SPAN_REGEX, ' ') : '';

  const wantsOff = naturalLanguage && (
    /\b(stop|disable|deactivate|quit|exit|kill)\s+(the\s+)?caveman\b/.test(nlPrompt) ||
    /\bcaveman(\s+mode)?\s+(off|stop|disabled?)\b/.test(nlPrompt) ||
    /\bturn\s+off\s+(the\s+)?caveman\b/.test(nlPrompt) ||
    // "normal mode" only as a command (prompt-initial, optionally led by a
    // switch-back verb) or with caveman context — never mid-sentence for
    // e.g. vim's normal mode ("how do I exit vim normal mode").
    /^(please\s+)?(go\s+(back\s+)?(to\s+)?|back\s+to\s+|switch\s+(back\s+)?to\s+|return\s+to\s+)?normal\s+mode\b/.test(nlPrompt) ||
    (/\bnormal\s+mode\b/.test(nlPrompt) && /\bcaveman\b/.test(nlPrompt))
  );
  if (wantsOff) return { action: 'clear' };

  // opencode expands a typed "/caveman <arg>", "/ultracave", "/megacave" (and
  // the independent-mode commands) into the command file's prose before
  // chat.message fires, so the literal slash-command branch below never sees
  // the original text. Recover the mode from each template's fixed prefix
  // instead. This MUST run before the generic NL-activation match below:
  // "Activate caveman mode: ultra" would otherwise trip the "activate ...
  // caveman" trigger and swallow the argument, activating at the default
  // instead (#602). Claude Code prompts never take this shape, so gate behind
  // expandedTpl (opencode-only).
  if (options.expandedTpl) {
    if (/^generate a commit message for the current staged changes\b/.test(prompt)) {
      return { action: 'set', mode: 'commit' };
    }
    if (/^review the current diff\b/.test(prompt)) {
      return { action: 'set', mode: 'review' };
    }
    if (/^compress the file at:/.test(prompt)) {
      return { action: 'set', mode: 'compress' };
    }
    const own = /^activate (ultracave|megacave) mode\b/.exec(prompt);
    if (own) return { action: 'set', mode: own[1] };
    const tpl = /^activate caveman mode:[ \t]*(\S*)/.exec(firstLine);
    if (tpl) return resolveModeArg(tpl[1], getDefaultMode);
  }

  if (naturalLanguage) {
    // Questions about caveman are not activation commands
    // ("what is caveman mode?", "does caveman lite drop articles?").
    const isQuestion =
      /^(what|whats|what's|how|why|when|where|who|does|do|did|is|are|can|could|would|should|tell me|explain)\b/.test(nlPrompt);

    // Natural language activation (e.g. "activate caveman", "turn on caveman
    // mode", "talk like caveman"). Also brevity requests ("less tokens",
    // "be brief/terse", "fewer tokens", "shorter answers") — but not when
    // scoped to a single section ("be brief in the summary"), which is a
    // one-off instruction, not a session-wide mode switch.
    if (!isQuestion) {
      if (wantsActivation(nlPrompt)) {
        const configured = getDefaultMode();
        const mode = configured === 'manual' ? 'caveman' : configured;
        // Mirrors the tracker exactly: a configured-off default makes this a
        // no-op (leave whatever flag state already exists), NOT a clear —
        // that's only what an explicit "/caveman" bare command does.
        return mode !== 'off' ? { action: 'set', mode } : null;
      }
    }
  }

  // Match /caveman commands. Marketplace plugin installs surface commands
  // namespaced as /caveman:caveman-<name> — accept both forms for every
  // skill (#599: only compress and stats had the namespaced variant).
  const parts = prompt.split(/\s+/);
  const cmd = parts[0]; // /caveman, /ultracave, /caveman-commit, etc.
  if (Object.prototype.hasOwnProperty.call(MODE_COMMANDS, cmd)) {
    // Same off/status words /caveman takes; anything else is just the mode.
    const arg = normalizeModeArg(parts[1]);
    if (arg === 'off' || arg === 'stop' || arg === 'disable') return { action: 'clear' };
    if (arg === 'status') return { action: 'status' };
    return { action: 'set', mode: MODE_COMMANDS[cmd] };
  }
  if (prompt.startsWith('/caveman')) {
    const arg = parts[1] || '';

    if (cmd === '/caveman-commit' || cmd === '/caveman:caveman-commit') {
      return { action: 'set', mode: 'commit' };
    }
    if (cmd === '/caveman-review' || cmd === '/caveman:caveman-review') {
      return { action: 'set', mode: 'review' };
    }
    if (cmd === '/caveman-compress' || cmd === '/caveman:caveman-compress') {
      return { action: 'set', mode: 'compress' };
    }
    if (cmd === '/caveman' || cmd === '/caveman:caveman') {
      // Bare /caveman → activate at configured default; otherwise resolve the
      // argument (punctuation-tolerant, bogus values reported not swallowed).
      return resolveModeArg(arg, getDefaultMode);
    }
  }

  return null;
}

module.exports = { parseModeChange, INDEPENDENT_MODES };
