# Icm-architect provenance

Bundled from `RinDig/icm-architect` under the MIT license.

- Upstream commit: `8bc2f5610d3843b3ffa31a142effe6b6337fef3c`
- Skill version: `0.1.0`
- Install is project-local. Companion hooks do not deny tools or hold completion.
