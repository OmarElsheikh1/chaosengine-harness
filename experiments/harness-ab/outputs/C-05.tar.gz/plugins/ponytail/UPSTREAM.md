# Ponytail provenance

Bundled from `DietrichGebert/ponytail` under the MIT license.

- Upstream commit: `7801d061243d7b753bad0e0b3c057cd250b11755`
- Skill version: `0.1.0`
- Install is project-local. Companion hooks do not deny tools or hold completion.
