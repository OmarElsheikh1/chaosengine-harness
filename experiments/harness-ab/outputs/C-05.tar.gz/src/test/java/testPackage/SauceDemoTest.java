package testPackage;

import com.shaft.driver.SHAFT;
import com.shaft.gui.internal.locator.Locator;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoTest {
    private SHAFT.GUI.WebDriver driver;
    private SHAFT.TestData.JSON testData;

    private final By usernameField = Locator.hasAnyTagName().hasId("user-name").build();
    private final By passwordField = Locator.hasAnyTagName().hasId("password").build();
    private final By loginButton = Locator.hasAnyTagName().hasId("login-button").build();
    private final By inventoryTitle = Locator.hasAnyTagName().hasAttribute("data-test", "title").build();
    private final By addBackpack = Locator.hasAnyTagName().hasId("add-to-cart-sauce-labs-backpack").build();
    private final By cartBadge = Locator.hasAnyTagName().hasAttribute("data-test", "shopping-cart-badge").build();
    private final By cartLink = Locator.hasAnyTagName().hasAttribute("data-test", "shopping-cart-link").build();
    private final By cartItemName = Locator.hasAnyTagName().hasAttribute("data-test", "inventory-item-name").build();
    private final By checkoutButton = Locator.hasAnyTagName().hasId("checkout").build();
    private final By firstNameField = Locator.hasAnyTagName().hasId("first-name").build();
    private final By lastNameField = Locator.hasAnyTagName().hasId("last-name").build();
    private final By postalCodeField = Locator.hasAnyTagName().hasId("postal-code").build();
    private final By continueButton = Locator.hasAnyTagName().hasId("continue").build();
    private final By finishButton = Locator.hasAnyTagName().hasId("finish").build();
    private final By completeHeader = Locator.hasAnyTagName().hasAttribute("data-test", "complete-header").build();

    @Test
    public void loginWithStandardUserShowsInventory() {
        openAndLogin();
        driver.browser().assertThat().url().contains("inventory.html");
        driver.element().assertThat(inventoryTitle).text().isEqualTo(testData.get("inventoryTitle"));
    }

    @Test
    public void addBackpackToCartAndCompleteCheckout() {
        openAndLogin();
        driver.element().click(addBackpack);
        driver.element().assertThat(cartBadge).text().isEqualTo("1");
        driver.element().click(cartLink);
        driver.element().assertThat(cartItemName).text().isEqualTo(testData.get("itemName"));
        driver.element().click(checkoutButton);
        driver.element().type(firstNameField, testData.get("firstName"))
                .type(lastNameField, testData.get("lastName"))
                .type(postalCodeField, testData.get("postalCode"));
        driver.element().click(continueButton);
        driver.element().click(finishButton);
        driver.element().assertThat(completeHeader).text().isEqualTo(testData.get("completeHeader"));
    }

    private void openAndLogin() {
        driver.browser().navigateToURL(testData.get("baseUrl"))
                .and().element().type(usernameField, testData.get("username"))
                .type(passwordField, testData.get("password"))
                .click(loginButton);
    }

    @BeforeClass
    public void beforeClass() {
        testData = new SHAFT.TestData.JSON("saucedemo.json");
    }

    @BeforeMethod
    public void beforeMethod() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        if (driver != null) {
            driver.quit();
        }
    }
}
