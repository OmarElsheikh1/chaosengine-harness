# SauceDemo SHAFT UI tests

Two TestNG UI tests for [SauceDemo](https://www.saucedemo.com/) on SHAFT Engine `10.4.20261112`.

- `loginWithStandardUserShowsInventory` signs in as `standard_user` and checks the inventory page.
- `addBackpackToCartAndCompleteCheckout` adds Sauce Labs Backpack and finishes checkout.

Requires JDK 25 and Maven 3.9+. Chrome is launched headless.

```bash
mvn test
```

Reports are written under `allure-results/` and `target/`.
