package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutCompletePage {
    private final SHAFT.GUI.WebDriver driver;
    private final By completeHeader = By.cssSelector("[data-test='complete-header']");

    public CheckoutCompletePage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutCompletePage assertOrderComplete(String expectedHeader) {
        driver.assertThat().browser().url().contains("checkout-complete.html");
        driver.element().assertThat(completeHeader).text().isEqualTo(expectedHeader);
        return this;
    }
}
