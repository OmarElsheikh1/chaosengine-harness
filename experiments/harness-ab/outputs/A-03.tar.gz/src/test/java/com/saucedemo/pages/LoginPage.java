package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class LoginPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By usernameField = By.id("user-name");
    private final By passwordField = By.id("password");
    private final By loginButton = By.id("login-button");

    public LoginPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open(String url) {
        driver.browser().navigateToURL(url);
        driver.element().assertThat(usernameField).isVisible();
        driver.element().assertThat(passwordField).isVisible();
        driver.element().assertThat(loginButton).isVisible();
        return this;
    }

    public InventoryPage login(String username, String password) {
        driver.element().type(usernameField, username);
        driver.element().type(passwordField, password);
        driver.element().click(loginButton);
        return new InventoryPage(driver);
    }
}
