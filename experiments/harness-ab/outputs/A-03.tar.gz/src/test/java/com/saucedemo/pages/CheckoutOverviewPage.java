package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutOverviewPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By subtotal = By.cssSelector("[data-test='subtotal-label']");
    private final By total = By.cssSelector("[data-test='total-label']");
    private final By finishButton = By.cssSelector("[data-test='finish']");

    public CheckoutOverviewPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutOverviewPage assertOrderSummary(String expectedItem, String expectedPrice, String expectedTotal) {
        driver.assertThat().browser().url().contains("checkout-step-two.html");
        driver.element().assertThat(itemName).text().isEqualTo(expectedItem);
        driver.element().assertThat(subtotal).text().contains(expectedPrice);
        driver.element().assertThat(total).text().contains(expectedTotal);
        return this;
    }

    public CheckoutCompletePage finish() {
        driver.element().click(finishButton);
        return new CheckoutCompletePage(driver);
    }
}
