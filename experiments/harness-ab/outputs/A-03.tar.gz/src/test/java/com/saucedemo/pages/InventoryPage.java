package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By title = By.cssSelector("[data-test='title']");
    private final By cartBadge = By.cssSelector("[data-test='shopping-cart-badge']");
    private final By cartLink = By.cssSelector("[data-test='shopping-cart-link']");

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public InventoryPage assertLoaded() {
        driver.assertThat().browser().url().contains("inventory.html");
        driver.element().assertThat(title).text().isEqualTo("Products");
        return this;
    }

    public InventoryPage addItem(String itemName) {
        driver.element().click(addToCartButton(itemName));
        driver.element().assertThat(removeButton(itemName)).isVisible();
        return this;
    }

    public InventoryPage assertCartCount(String count) {
        driver.element().assertThat(cartBadge).text().isEqualTo(count);
        return this;
    }

    public CartPage openCart() {
        driver.element().click(cartLink);
        return new CartPage(driver);
    }

    private By addToCartButton(String itemName) {
        return By.cssSelector("[data-test='add-to-cart-" + slug(itemName) + "']");
    }

    private By removeButton(String itemName) {
        return By.cssSelector("[data-test='remove-" + slug(itemName) + "']");
    }

    private String slug(String itemName) {
        return itemName.toLowerCase().replace(' ', '-');
    }
}
