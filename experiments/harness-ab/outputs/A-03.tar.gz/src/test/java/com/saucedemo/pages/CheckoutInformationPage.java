package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutInformationPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By firstNameField = By.cssSelector("[data-test='firstName']");
    private final By lastNameField = By.cssSelector("[data-test='lastName']");
    private final By postalCodeField = By.cssSelector("[data-test='postalCode']");
    private final By continueButton = By.cssSelector("[data-test='continue']");

    public CheckoutInformationPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutOverviewPage enterCustomerInformation(String firstName, String lastName, String postalCode) {
        driver.assertThat().browser().url().contains("checkout-step-one.html");
        driver.element().type(firstNameField, firstName);
        driver.element().type(lastNameField, lastName);
        driver.element().type(postalCodeField, postalCode);
        driver.element().click(continueButton);
        return new CheckoutOverviewPage(driver);
    }
}
