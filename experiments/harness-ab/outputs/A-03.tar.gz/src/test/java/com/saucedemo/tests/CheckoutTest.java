package com.saucedemo.tests;

import com.saucedemo.pages.LoginPage;
import org.testng.annotations.Test;

public class CheckoutTest extends BaseTest {

    @Test
    public void addItemToCartAndCompleteCheckout() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"))
                .addItem(testData.get("itemName"))
                .assertCartCount(testData.get("cartCount"))
                .openCart()
                .assertItemPresent(testData.get("itemName"))
                .checkout()
                .enterCustomerInformation(
                        testData.get("firstName"),
                        testData.get("lastName"),
                        testData.get("postalCode"))
                .assertOrderSummary(
                        testData.get("itemName"),
                        testData.get("itemPrice"),
                        testData.get("orderTotal"))
                .finish()
                .assertOrderComplete(testData.get("completeHeader"));
    }
}
