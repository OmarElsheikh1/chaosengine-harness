package saucedemo.tests;

import org.testng.annotations.Test;
import saucedemo.pages.LoginPage;

public class CheckoutTest extends SauceDemoTestBase {

    @Test
    public void addBackpackToCartAndCompleteCheckout() {
        new LoginPage(driver)
                .open()
                .login(testData.get("username"), testData.get("password"))
                .addItem(testData.get("addToCartButtonId"))
                .assertCartCount(testData.get("cartCount"))
                .openCart()
                .assertItemPresent(testData.get("cartPath"), testData.get("itemName"))
                .checkout()
                .enterCustomer(testData.get("firstName"), testData.get("lastName"), testData.get("postalCode"))
                .assertOrderSummary(
                        testData.get("overviewPath"),
                        testData.get("itemName"),
                        testData.get("itemTotalLabel"),
                        testData.get("totalLabel"))
                .finish()
                .assertOrderCompleted(
                        testData.get("completePath"),
                        testData.get("completeHeader"),
                        testData.get("completeText"));
    }
}
