package saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By postalCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By itemTotal = By.cssSelector("[data-test='subtotal-label']");
    private final By grandTotal = By.cssSelector("[data-test='total-label']");
    private final By finishButton = By.id("finish");
    private final By completeHeader = By.cssSelector("[data-test='complete-header']");
    private final By completeText = By.cssSelector("[data-test='complete-text']");

    public CheckoutPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutPage enterCustomer(String firstName, String lastName, String postalCode) {
        ReactInput.type(driver, firstNameField, firstName);
        ReactInput.type(driver, lastNameField, lastName);
        ReactInput.type(driver, postalCodeField, postalCode);
        ReactClick.click(driver, continueButton);
        return this;
    }

    public CheckoutPage assertOrderSummary(String overviewPath, String expectedItemName, String expectedItemTotal, String expectedGrandTotal) {
        driver.browser().assertThat().url().contains(overviewPath);
        driver.element().assertThat(itemName).text().isEqualTo(expectedItemName);
        driver.element().assertThat(itemTotal).text().isEqualTo(expectedItemTotal);
        driver.element().assertThat(grandTotal).text().isEqualTo(expectedGrandTotal);
        return this;
    }

    public CheckoutPage finish() {
        ReactClick.click(driver, finishButton);
        return this;
    }

    public CheckoutPage assertOrderCompleted(String completePath, String expectedHeader, String expectedText) {
        driver.browser().assertThat().url().contains(completePath);
        driver.element().assertThat(completeHeader).text().isEqualTo(expectedHeader);
        driver.element().assertThat(completeText).text().isEqualTo(expectedText);
        return this;
    }
}
