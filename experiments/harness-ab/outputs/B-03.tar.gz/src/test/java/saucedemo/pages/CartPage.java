package saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CartPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By itemName = By.cssSelector("[data-test='inventory-item-name']");
    private final By checkoutButton = By.id("checkout");

    public CartPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CartPage assertItemPresent(String cartPath, String expectedItemName) {
        driver.browser().assertThat().url().contains(cartPath);
        driver.element().assertThat(itemName).text().isEqualTo(expectedItemName);
        return this;
    }

    public CheckoutPage checkout() {
        ReactClick.click(driver, checkoutButton);
        return new CheckoutPage(driver);
    }
}
