package saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

final class ReactClick {
    private ReactClick() {
    }

    /**
     * Sauce Demo wires these controls with React onClick. Headless Chrome reports WebDriver's
     * native click as a success without running that handler. {@code HTMLElement.click()} does.
     */
    static void click(SHAFT.GUI.WebDriver driver, By locator) {
        driver.element().clickUsingJavascript(locator);
    }
}
