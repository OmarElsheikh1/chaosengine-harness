package saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

final class ReactInput {
    /**
     * Assigning {@code element.value} does not notify a React controlled input. The native setter
     * plus a reset value tracker makes the following input event look like a user edit.
     */
    private static final String SET_CONTROLLED_VALUE = """
            const element = arguments[0];
            const value = arguments[1];
            const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
            const lastValue = element.value;
            descriptor.set.call(element, value);
            const tracker = element._valueTracker;
            if (tracker) {
                tracker.setValue(lastValue);
            }
            element.dispatchEvent(new Event('input', { bubbles: true }));
            element.dispatchEvent(new Event('change', { bubbles: true }));
            return element.value;
            """;

    private ReactInput() {
    }

    static void type(SHAFT.GUI.WebDriver driver, By locator, String value) {
        driver.element().assertThat(locator).exists();
        WebElement element = driver.getDriver().findElement(locator);
        Object actual = ((JavascriptExecutor) driver.getDriver()).executeScript(SET_CONTROLLED_VALUE, element, value);
        if (!value.equals(actual)) {
            throw new IllegalStateException("Field " + locator + " kept '" + actual + "' after typing '" + value + "'.");
        }
    }
}
