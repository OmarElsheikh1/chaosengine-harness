package saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage {
    private final SHAFT.GUI.WebDriver driver;
    private final By productsTitle = By.cssSelector("[data-test='title']");
    private final By cartBadge = By.cssSelector("[data-test='shopping-cart-badge']");
    private final By cartLink = By.cssSelector("[data-test='shopping-cart-link']");

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public InventoryPage assertCatalogIsOpen(String inventoryPath, String expectedTitle) {
        driver.browser().assertThat().url().contains(inventoryPath);
        driver.element().assertThat(productsTitle).text().isEqualTo(expectedTitle);
        return this;
    }

    public InventoryPage addItem(String addToCartButtonId) {
        ReactClick.click(driver, By.id(addToCartButtonId));
        return this;
    }

    public InventoryPage assertCartCount(String expectedCount) {
        driver.element().assertThat(cartBadge).text().isEqualTo(expectedCount);
        return this;
    }

    public CartPage openCart() {
        ReactClick.click(driver, cartLink);
        return new CartPage(driver);
    }
}
