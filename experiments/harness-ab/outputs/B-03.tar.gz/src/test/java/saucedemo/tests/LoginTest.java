package saucedemo.tests;

import org.testng.annotations.Test;
import saucedemo.pages.LoginPage;

public class LoginTest extends SauceDemoTestBase {

    @Test
    public void standardUserLogsInAndSeesTheProductCatalog() {
        new LoginPage(driver)
                .open()
                .login(testData.get("username"), testData.get("password"))
                .assertCatalogIsOpen(testData.get("inventoryPath"), testData.get("productsTitle"));
    }
}
