package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutOverviewPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By backpackLink = SHAFT.GUI.Locator.hasAnyTagName().hasId("item_4_title_link").build();
    private final By finishButton = SHAFT.GUI.Locator.hasAnyTagName().hasId("finish").build();

    public CheckoutOverviewPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutOverviewPage assertContainsItem(String itemName, String checkoutOverviewPath) {
        driver.browser().assertThat().url().contains(checkoutOverviewPath);
        driver.element().assertThat(backpackLink).textTrimmed().isEqualTo(itemName);
        return this;
    }

    public CheckoutCompletePage finish() {
        ReactControls.click(driver, finishButton);
        return new CheckoutCompletePage(driver);
    }
}
