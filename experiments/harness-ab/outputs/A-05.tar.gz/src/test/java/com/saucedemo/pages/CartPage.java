package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CartPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By backpackLink = SHAFT.GUI.Locator.hasAnyTagName().hasId("item_4_title_link").build();
    private final By checkoutButton = SHAFT.GUI.Locator.hasAnyTagName().hasId("checkout").build();

    public CartPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CartPage assertContainsItem(String itemName, String cartPath) {
        driver.browser().assertThat().url().contains(cartPath);
        driver.element().assertThat(backpackLink).textTrimmed().isEqualTo(itemName);
        return this;
    }

    public CheckoutInformationPage proceedToCheckout() {
        ReactControls.click(driver, checkoutButton);
        return new CheckoutInformationPage(driver);
    }
}
