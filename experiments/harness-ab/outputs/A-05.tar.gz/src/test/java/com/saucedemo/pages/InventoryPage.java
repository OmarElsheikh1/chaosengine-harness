package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class InventoryPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By productsTitle = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "title")
            .build();
    private final By addBackpackButton = SHAFT.GUI.Locator.hasAnyTagName()
            .hasId("add-to-cart-sauce-labs-backpack")
            .build();
    private final By cartBadge = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "shopping-cart-badge")
            .build();
    private final By cartLink = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "shopping-cart-link")
            .build();

    public InventoryPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public InventoryPage assertLoaded(String expectedTitle, String inventoryPath) {
        driver.browser().assertThat().url().contains(inventoryPath);
        driver.element().assertThat(productsTitle).textTrimmed().isEqualTo(expectedTitle);
        return this;
    }

    public InventoryPage addSauceLabsBackpackToCart() {
        ReactControls.click(driver, addBackpackButton);
        return this;
    }

    public InventoryPage assertCartBadgeCount(String expectedCount) {
        driver.element().assertThat(cartBadge).textTrimmed().isEqualTo(expectedCount);
        return this;
    }

    public CartPage openCart() {
        ReactControls.click(driver, cartLink);
        return new CartPage(driver);
    }
}
