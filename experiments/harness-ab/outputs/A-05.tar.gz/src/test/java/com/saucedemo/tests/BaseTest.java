package com.saucedemo.tests;

import com.shaft.driver.SHAFT;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseTest {
    protected SHAFT.GUI.WebDriver driver;
    protected static SHAFT.TestData.JSON testData;

    @BeforeClass
    public void loadTestData() {
        testData = new SHAFT.TestData.JSON("sauceDemo.json");
    }

    @BeforeMethod
    public void openBrowser() {
        driver = new SHAFT.GUI.WebDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}
