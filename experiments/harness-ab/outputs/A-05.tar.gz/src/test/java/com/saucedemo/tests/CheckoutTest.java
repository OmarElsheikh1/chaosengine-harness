package com.saucedemo.tests;

import com.saucedemo.pages.LoginPage;
import org.testng.annotations.Test;

public class CheckoutTest extends BaseTest {

    @Test
    public void addBackpackToCartAndCompleteCheckout() {
        new LoginPage(driver)
                .open(testData.get("baseUrl"))
                .login(testData.get("username"), testData.get("password"))
                .addSauceLabsBackpackToCart()
                .assertCartBadgeCount(testData.get("expectedCartCount"))
                .openCart()
                .assertContainsItem(testData.get("itemName"), testData.get("cartPath"))
                .proceedToCheckout()
                .assertLoaded(testData.get("checkoutInformationPath"))
                .enterCustomerInformation(
                        testData.get("firstName"),
                        testData.get("lastName"),
                        testData.get("postalCode"))
                .continueToOverview()
                .assertContainsItem(testData.get("itemName"), testData.get("checkoutOverviewPath"))
                .finish()
                .assertOrderIsComplete(
                        testData.get("orderCompleteHeader"),
                        testData.get("checkoutCompletePath"));
    }
}
