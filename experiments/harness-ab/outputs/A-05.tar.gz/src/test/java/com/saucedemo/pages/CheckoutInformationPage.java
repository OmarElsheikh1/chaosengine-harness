package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutInformationPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By firstNameField = SHAFT.GUI.Locator.hasAnyTagName().hasId("first-name").build();
    private final By lastNameField = SHAFT.GUI.Locator.hasAnyTagName().hasId("last-name").build();
    private final By postalCodeField = SHAFT.GUI.Locator.hasAnyTagName().hasId("postal-code").build();
    private final By continueButton = SHAFT.GUI.Locator.hasAnyTagName().hasId("continue").build();

    public CheckoutInformationPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutInformationPage assertLoaded(String checkoutInformationPath) {
        driver.browser().assertThat().url().contains(checkoutInformationPath);
        return this;
    }

    public CheckoutInformationPage enterCustomerInformation(String firstName, String lastName, String postalCode) {
        ReactControls.type(driver, firstNameField, firstName);
        ReactControls.type(driver, lastNameField, lastName);
        ReactControls.type(driver, postalCodeField, postalCode);
        return this;
    }

    public CheckoutOverviewPage continueToOverview() {
        ReactControls.click(driver, continueButton);
        return new CheckoutOverviewPage(driver);
    }
}
