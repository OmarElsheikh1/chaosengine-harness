package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class LoginPage {
    private final SHAFT.GUI.WebDriver driver;

    private final By usernameField = SHAFT.GUI.Locator.hasAnyTagName().hasId("user-name").build();
    private final By passwordField = SHAFT.GUI.Locator.hasAnyTagName().hasId("password").build();
    private final By loginButton = SHAFT.GUI.Locator.hasAnyTagName().hasId("login-button").build();

    public LoginPage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open(String baseUrl) {
        driver.browser().navigateToURL(baseUrl);
        return this;
    }

    public InventoryPage login(String username, String password) {
        driver.element().type(usernameField, username)
                .and().element().type(passwordField, password)
                .and().element().click(loginButton);
        return new InventoryPage(driver);
    }
}
