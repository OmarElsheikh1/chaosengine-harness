package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

final class ReactControls {
    private ReactControls() {
    }

    /**
     * SauceDemo's React buttons and links ignore a native WebDriver click in headless Chrome:
     * the click is reported as successful and the handler never runs. {@code HTMLElement.click()}
     * dispatches the event React listens for.
     */
    static void click(SHAFT.GUI.WebDriver driver, By locator) {
        driver.element().clickUsingJavascript(locator);
    }

    /**
     * Checkout fields are controlled inputs. After client-side navigation, sendKeys reports
     * success and React still keeps the previous value. Set the value through the prototype
     * setter and dispatch {@code input} so the React state updates.
     */
    static void type(SHAFT.GUI.WebDriver driver, By locator, String value) {
        driver.element().assertThat(locator).exists();
        ((JavascriptExecutor) driver.getDriver()).executeScript("""
                const element = arguments[0];
                const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value').set;
                setter.call(element, arguments[1]);
                element.dispatchEvent(new Event('input', { bubbles: true }));
                """, driver.getDriver().findElement(locator), value);
    }
}
