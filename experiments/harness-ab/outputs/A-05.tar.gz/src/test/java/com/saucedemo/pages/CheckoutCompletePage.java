package com.saucedemo.pages;

import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;

public class CheckoutCompletePage {
    private final SHAFT.GUI.WebDriver driver;

    private final By completeHeader = SHAFT.GUI.Locator.hasAnyTagName()
            .hasAttribute("data-test", "complete-header")
            .build();

    public CheckoutCompletePage(SHAFT.GUI.WebDriver driver) {
        this.driver = driver;
    }

    public CheckoutCompletePage assertOrderIsComplete(String expectedHeader, String checkoutCompletePath) {
        driver.browser().assertThat().url().contains(checkoutCompletePath);
        driver.element().assertThat(completeHeader).textTrimmed().isEqualTo(expectedHeader);
        return this;
    }
}
